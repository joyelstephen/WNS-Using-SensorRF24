<?php
	/***********************************************************
	 *  NOTE: edit this config details with correct credentials 
	 ***********************************************************/
	 
	//Set the account email
	define('USER_EMAIL', 'your-email-address');

	//set the service password
	define('PASSWORD', 'your-password');

	//set the api key
	define('API_KEY', 'you-api-key');

?>

